document.addEventListener("DOMContentLoaded", () => {
    
})

function getBirthdayValue() {
    const birthdayInput = document.getElementById("birthday");

    const personYear = new Date(birthdayInput.value);
    const today = new Date();

    const ageElement = document.getElementById("age")

    ageElement.value = today.getFullYear() - personYear.getFullYear();
}

function addItem() {
    const container_list = document.getElementById("container-list")

    const title = document.createElement("div")
    title.innerHTML = 
    `<div class="text-bg-primary rounded-4 p-2 mb-2">
                <h5>Fullname</h5>
               <div class="row">
                <div class="col">
                    <span>Occupation : Para luto</span>
                </div>
                <div class="col">
                    <span>Birthday : 2024-11-19</span>
                </div>
                <div class="col-auto">
                    <span>Age : 200</span>
                </div>
                <div class="col-auto">
                    <span>Gender : Others</span>
                </div>
                <div class="col d-flex gap-2">
                    <button type="button" class="btn btn-light w-100">Edit</button>
                    <button type="button" class="btn btn-danger w-100">Delete</button>
                </div>
               </div>
            </div>`;
    container_list.appendChild(title)
}