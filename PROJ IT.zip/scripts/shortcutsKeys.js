document.addEventListener("keyup", (key) => {
    // console.log(key.key);
    // focusOnInput("amount");

    // if (key.key == "A") {
        //     console.log("Big A")
        // } else if (key.key == "a") {
        //     console.log("small A")
        // }

    if (key.key == "Escape") {
        if (confirm("Are sure you wanna quit?")) {
            console.log("quiting...")
            location.href = "../index.html"
        }
    }

    if (key.key == "S") {
        focusOnInput("splitbtn")
    } else if (key.key == "F") {
        focusOnInput("fullbtn")
    }

    if (key.key == "A") {
        focusOnInput("amount")
    }
});

function focusOnInput(inputElement, isfocus = "focus") {
    if (isfocus == "focus") {
        document.getElementById(inputElement).focus();
    }else {
        document.getElementById(inputElement).click();
    }
}