// initialize the list
let persons = [];

// when the page loads
document.addEventListener("DOMContentLoaded", () => {
    // window.alert("Hello ther")

    
});

function get_age() {
    const bd = document.getElementById('birthdate');
    const today = new Date();
    let date_today = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    bd.setAttribute("max", date_today)

    const ageEle = document.getElementById('age')
    const pbd = new Date(bd.value)
    ageEle.value = today.getFullYear() - pbd.getFullYear();
}

function add_item(_id, _occupation, _birthdate, _gender, _age) {
    const container = document.getElementById("list-container");

    const item = document.createElement("div");
    item.classList.add("text-bg-primary");
    item.classList.add("rounded-4");
    item.classList.add("p-3");
    item.classList.add("mb-2");
    const heading = document.createElement("h4");
    heading.innerText = "Test Fullname";
    item.appendChild(heading);
    const row = document.createElement("div");
    row.classList.add("row");
    row.classList.add("gap-1");
    row.innerHTML = 
    `
    <div class="col">
        <span>Occupation: ${ _occupation }</span>
    </div>
    <div class="col">
        <span>Birth date: ${ _birthdate}</span>
    </div>
    <div class="col">
        <span>Gender: ${ _gender }</span>
    </div>
    <div class="col-auto">
        <span>Age: ${ _age }</span>
    </div>
    <div class="col-auto">
        <button type="button" class="btn btn-light" id="edit" onclick="${ _id }">Edit</button>
        <button type="button" class="btn btn-danger" id="delete" onclick="${ _id }">Delete</button>
    </div>
    `;
    item.appendChild(row);

    // add it to the list container
    container.appendChild(item);
}